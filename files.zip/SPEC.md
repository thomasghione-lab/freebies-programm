# SPEC: Opportunity Finder engineering contract (v0.1, Step 1)

Audience: any engineer or AI contributing code. Read this before touching anything. The product brief describes *what*
we build; this document says *how the code must behave*. Where they differ, this file records the decision.

## 1. Principles

1. **Trust over quantity.** A wrong "verified eligible" or a prize shown as income is worse than a missing listing.
2. **Fail closed.** Unknown eligibility is `UNKNOWN`, unassessed risk is `UNASSESSED`, unknown requirements are `None`.
   Nothing unknown is ever presented as good news.
3. **Collectors extract, engines decide.** Collectors produce facts *with evidence*. Eligibility, risk and scoring are
   separate stages that will not trust a collector's opinion.
4. **Every claim is provable.** A value that drives a decision carries a verbatim snippet that the pipeline re-checks
   against the fetched document.
5. **Permission is written down.** We only collect from sources whose registry entry says why access is allowed.
6. **The user controls submission.** The platform discovers and prepares; it never submits or agrees on the user's behalf.

## 2. Architecture

```
SourceRegistry (permission record) ──gate──▶ Collector ──▶ Fetcher ──▶ RawDocument
                                               parse() pure                │
Repository ◀── validate_opportunity + verify_evidence ◀── Opportunity[] ◀──┘
     │
     ├──▶ eligibility engine (Step 2)  writes: eligibility rows
     ├──▶ risk engine        (Step 4)  writes: risk level/score/flags
     ├──▶ dedup              (Step 5)  writes: opportunity_mirrors
     └──▶ scoring            (Step 6)  writes: scores
```

Ownership of data (who may write what):

| Data | Written by |
|---|---|
| opportunities (facts), rewards, evidence, categories, mirrors | collectors via the runner |
| eligibility, eligibility_evidence | eligibility engine |
| risk_level, risk_score, scam flags | risk engine |
| scores | scoring stage |
| source_runs | runner |

## 3. Module contracts

- `Collector.urls() -> Sequence[str]`; `Collector.parse(doc, ctx) -> ParseResult`. `parse` is pure. Everything else
  (fetching, gating, verification, storage) belongs to the pipeline.
- `Fetcher.fetch(url) -> RawDocument`, with `is_live: bool`. Only `FixtureFetcher` exists. A future live fetcher is its own
  reviewed module (see SECURITY.md section 4).
- `run_source(source, collector, repo, now) -> RunReport`. Every run, including a refusal, is written to `source_runs`.
- `Repository` is the only code that contains SQL. Parameterised queries only.

## 4. Guaranteed vs chance-based (the trust core)

Every reward has a **certainty** and a **value basis**.

| Certainty | Meaning | Example |
|---|---|---|
| `GUARANTEED` | Do the stated task, get the reward | Paid interview, A$100 |
| `CONDITIONAL` | Guaranteed once stated conditions are met | Welcome bonus after spending $500 |
| `SELECTION_BASED` | Real reward, but you must be screened/selected in | "Apply to keep a A$200 jacket" |
| `CHANCE_BASED` | Random draw | Win a A$5,000 trip |

| Value basis | Meaning |
|---|---|
| `CASH_PAID` | Money you receive |
| `STATED_VALUE` | Face value of a gift card or credit |
| `RETAIL_VALUE` | Retail price of goods/services you would receive |
| `PRIZE_VALUE` | Advertised value of a draw prize. **Never income.** |

Enforced in `Reward.__post_init__` **and** as SQL CHECK constraints:

- R1: `CHANCE_BASED` if and only if `PRIZE_VALUE`.
- R2: money is `Decimal`, at most 2 decimals, non-negative, supported currency (stored as integer cents). No floats.
- R3: amount and currency are given together.
- R4: reward type limits the basis (a product, trip or gift card is never `CASH_PAID`).

Derived views on `Opportunity`:

- `guaranteed_cash_by_currency()` counts **only** `GUARANTEED` + `CASH` + `CASH_PAID`. This is the only figure that may
  ever be treated as income.
- `guaranteed_cash_per_hour(currency)` returns `None` unless both cash and time are known.
- `stated_prize_value_by_currency()` is a label, not expected income. No probabilities are invented.
- `lane` is `GUARANTEED`, `SELECTION_BASED`, `CHANCE_BASED` or `UNKNOWN`. Lanes are ranked separately, never mixed.
  A mixed opportunity takes its strongest certainty; the draw part is never added to its guaranteed cash.
- Currencies are never summed together.

## 5. Eligibility model

Status is per market (`AU`, `FR`): `ELIGIBLE_VERIFIED` (GREEN), `LIKELY_ELIGIBLE` (YELLOW), `UNKNOWN` (YELLOW, "needs terms
check", never a claim), `NOT_ELIGIBLE` (RED). A market with no row is `UNKNOWN`.

Invariants (`EligibilityAssessment`, DB CHECKs, and `validate_opportunity`):

- `UNKNOWN` implies `LOW` confidence.
- Any non-`UNKNOWN` status needs a real basis and at least one evidence id belonging to that opportunity.
- `ELIGIBLE_VERIFIED` needs `HIGH` confidence, a strong basis (not `SOURCE_MARKET_ONLY`), and either an explicit country
  list or `terms_checked=True` (worldwide/region statements only reach GREEN if the terms were actually read).
- `ELIGIBLE_VERIFIED` may not rest on LLM-extracted evidence alone.
- `NOT_ELIGIBLE` may not rest on `SOURCE_MARKET_ONLY` (never hide an opportunity on a hunch).

Collectors capture the **raw** `eligibility_text` (with evidence). Interpreting it is the eligibility engine's job (Step 2).
`stated_eligible_countries` is only for sources that publish an explicit structured country list.

## 6. Evidence

`Evidence(field, value, snippet, source_url, retrieved_at, method, confidence, content_hash)`.

- E1: every populated claim field needs evidence: each `rewards[i]`, `estimated_minutes`, `closing_date`,
  `eligibility_text`, `entry_frequency`, `availability`, `stated_eligible_countries`, and each non-`None` `requires_*` flag.
- E2: evidence may not reference a field that does not exist.
- E3/E4: eligibility may only cite the opportunity's own evidence; LLM-only evidence cannot verify.
- Verification (`pipeline/verification.py`): the cited document must have been fetched in this run, its hash must match,
  and the snippet must appear in its visible text. This defeats fabricated or injected "supporting quotes".

Violations are `ERROR`s: the opportunity is rejected and reported in the run log. Warnings (e.g. no reward found) are reported only.

## 7. Source registry

`SourceDefinition` records permission basis, terms URL and human review date, robots.txt check date, request-interval
floor (>= 2 s), status, reliability. Rules:

- `ENABLED` requires a live-capable permission basis and a recorded human terms review (the constructor refuses otherwise).
- A terms review older than 180 days blocks live collection until re-reviewed.
- Live fetchers require `ENABLED`; `FIXTURE_ONLY` sources may only run against saved HTML. `DISABLED`/`SUSPENDED` run nothing.
- The default registry contains only the fictional `mock-competitions`. A test fails if any source is `ENABLED`, so
  enabling one is a deliberate, reviewed act.

## 8. Database

`backend/database/schema.sql`, portable SQL (SQLite now, PostgreSQL later): ISO-8601 UTC text timestamps, `INTEGER`
booleans (`NULL` = unknown), money as integer cents, text ids generated in Python.

Tables: `users, profiles, opportunities, sources, eligibility, scores, participation_history, saved_opportunities, alerts,
source_runs` (from the brief) plus `opportunity_mirrors` (canonical + mirrors for dedup), `opportunity_categories`,
`opportunity_countries`, `opportunity_rewards`, `opportunity_scam_flags`, `evidence`, `eligibility_evidence`,
`schema_migrations`.

- `users`/`profiles` are DDL only for now, deliberately holding **no password, email, name or address**.
- Enum CHECK lists are compared with the Python enums by a test, so schema and code cannot drift.
- Re-collecting an opportunity replaces its child rows and therefore resets engine-owned fields to fail-closed defaults
  (see Open Decision 4).

## 8b. Mapping from the product brief's minimum fields

| Brief field | Where it lives |
|---|---|
| id, title, provider, source_url, official_url, terms_url, country, description | same names on `Opportunity` |
| eligible_countries[] | `stated_eligible_countries` (raw claim) + per-market `eligibility` assessments |
| category[] | `categories` |
| cash_value, cash_currency | `rewards[]` with `GUARANTEED`/`CASH_PAID`; see `guaranteed_cash_by_currency()` |
| product_value, product_currency | `rewards[]` of type `PRODUCT` (`RETAIL_VALUE`) |
| estimated_minutes | `estimated_minutes` (float, so 30 seconds = 0.5) |
| estimated_total_effort | `effort_level` (set later; collectors may leave `UNKNOWN`) |
| entry_type | `entry_type`; also new `entry_frequency` |
| requires_* (6 flags) | same names, tri-state (`None` = unknown) |
| closing_date | `closing_date` + `closing_tz` |
| availability | `availability` |
| eligibility_text | `eligibility_text` |
| eligibility_confidence | `eligibility[country].confidence` |
| risk_score, scam_flags[] | `risk.score`, `risk.flags` (+ `risk.level`, default `UNASSESSED`) |
| value_score, effort_score, expected_value_score, priority_score | `scores` table (Step 6), not on the collector output |
| first_seen, last_verified, source_type | same names |
| (new) | `source_id`, `external_id`, `rewards[]`, `evidence[]`, derived `lane` |

## 9. Conventions

- Python 3.11+. Type hints everywhere. Dataclasses, frozen, validated in `__post_init__`.
- Timestamps are timezone-aware UTC (naive datetimes are rejected). Collectors receive time via `ctx.now`.
- Errors: `DomainValidationError` for bad data, `ParseError` for a listing that cannot be trusted, `FetchError` for I/O.
- Adding an enum value means updating `enums.py` **and** `schema.sql` (the drift test enforces it).
- Renderers must HTML-escape all stored text. Stored text is data, never markup (see SECURITY.md).

## 10. Open decisions for the architect

1. **Dataclasses instead of Pydantic.** The build environment had no network, so Pydantic v2, SQLAlchemy and pytest could
   not be installed or verified. Everything was built with the standard library so all 142 tests could run.
   Recommendation: keep the tests as the contract and migrate `domain/` to Pydantic v2 in Step 2 once it can be installed
   and verified; the field names and rules are designed to carry over unchanged.
2. **Three lanes, not two.** The brief says guaranteed vs chance. Screened paid studies and "apply to keep it" product
   tests are neither: the reward is real, access is uncertain. I added `SELECTION_BASED`. Should it rank with guaranteed
   (discounted) or separately?
3. **What makes GREEN?** Today an explicit country list on the listing page is enough. Stricter option: always require the
   terms page to have been read (`terms_checked`). Stricter means almost no GREEN until a terms fetcher exists.
4. **Re-collection resets engine output.** Safe but means engines must run after every collection. Alternative: keep
   assessments when the facts hash is unchanged.
5. **Empty feed until the risk engine exists.** `UNASSESSED` is excluded from the main feed, so a dashboard built now would
   show nothing. Do we want an "unreviewed" admin view for development?
6. **Evidence strictness will reject real listings** whose values the parser cannot quote. That is intended; watch the
   rejection rate per source and treat a rise as a broken parser.
7. **Currencies limited** to AUD, EUR, USD, GBP, NZD, CAD (two-decimal currencies only, stored as cents).
8. **Deadlines** are stored as a date plus an optional IANA zone as stated. Converting to an absolute instant, and what to
   do when no zone is stated, is left to the scoring stage.

## 11. Roadmap status (brief section 17)

| # | Task | Status |
|---|---|---|
| 1 | Repository structure | Done |
| 2 | Opportunity schema | Done (+ evidence, rewards, certainty) |
| 3 | SQLite models | Done (`schema.sql`, `Repository`) |
| 4 | One collector per category | **Deliberately not started**: one mock collector proves the architecture first |
| 5 | Normalisation | Started (money, duration, text) |
| 6 | Eligibility engine | Next (Step 2) |
| 7 | Risk flags | Step 4 |
| 8 | Scoring | Step 6 |
| 9 | Dashboard | Later |
| 10 | Tests per stage | Done for stages that exist |

Suggested next step (Step 2): the **eligibility engine**, a pure function from `eligibility_text` (+ evidence) to per-market
`EligibilityAssessment`s, test-driven against the mock fixtures (`mock-002` "Australia only", `mock-004` French residents,
`mock-005` ambiguous, `mock-006` "US residents only").
