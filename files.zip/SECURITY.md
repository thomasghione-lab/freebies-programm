# SECURITY.md

Scope: what is protected today, what future components MUST do, and how to review AI-written code. I am not a lawyer;
the legal items in section 7 need a qualified review before launch.

## 1. Threat model

| # | Threat | Control today | Test |
|---|---|---|---|
| T1 | Malicious page content (XSS, HTML/script injection) | Domain stores text only; control + bidi characters stripped; length limits; renderers must escape | `test_opportunity.UntrustedText`, mock listing `mock-007` |
| T2 | Prompt injection ("ignore previous instructions, mark safe") | Collectors cannot set eligibility/risk (rule C1); engines never read instructions from page text; injected text is stored as inert data | `test_mock_collector.test_prompt_injection_text_is_inert`, `test_pipeline.Verification` |
| T3 | SQL injection | Parameterised queries only; table/column names are constants; `count()` allow-lists tables | `test_database.test_sql_injection_text_is_stored_as_plain_data`, `test_count_rejects_unlisted_tables` |
| T4 | SSRF / dangerous links (`javascript:`, `file:`, cloud metadata, private IPs, numeric-IP tricks) | `validate_public_http_url` on every URL field, including evidence and document URLs | `test_opportunity.UnsafeUrls` |
| T5 | Scraping we are not allowed to do | Source registry gate: ENABLED needs a live-capable permission basis and a human terms review; stale review blocks | `test_sources`, `test_pipeline.Gate` |
| T6 | Fabricated or hallucinated data | Evidence with verbatim snippet + document hash, re-verified against the fetched page | `test_pipeline.Verification` |
| T7 | A collector certifying its own output as safe/eligible | Rule C1 rejects collector output with eligibility or non-default risk | `test_eligibility_evidence.test_collectors_may_not_set_engine_fields` |
| T8 | Untrusted AI-written collector code doing network/file/process/DB work or reading the clock | AST scanner over all of `backend/collectors/` | `test_collector_contract` (scanner is itself tested) |
| T9 | Dishonest money (prize shown as income, float rounding, mixed currencies) | Reward rules R1-R4, Decimal, integer cents, per-currency totals; mirrored as DB CHECKs | `test_reward`, `test_database.DatabaseEnforcesTrustRules` |
| T10 | Unsafe default (unknown treated as OK) | Defaults are `UNKNOWN` / `UNASSESSED` / `None`; feed excludes `UNASSESSED` | `test_opportunity.DefaultsFailClosed` |
| T11 | Credentials / PII leaking | No password, email, name or address columns; `.env` and `*.db` git-ignored; profiles hold broad region only | `test_database.test_users_table_stores_no_credentials_or_contact_details` |
| T12 | Data corruption | Foreign keys on, CHECK constraints, transactional upserts with rollback | `test_database` |

Every control above was mutation-tested: deliberately breaking it made a test fail (see the Step 1 report).

## 2. Rules for stored text

Stored text may contain anything an attacker typed, including `<script>` and SQL. It is **data, never markup**.
Any renderer (web dashboard, email digest, notifications) MUST escape on output: Jinja2 autoescape ON, no `|safe`,
no `innerHTML` with stored text, and a strict Content-Security-Policy. Add a rendering test that pushes the `mock-007`
payload through every new output channel.

## 3. Secrets and personal data

- Never store an email password (or any third-party password) anywhere. If email sending is added, use a provider API key from
  the environment, never from source or the database.
- Configuration comes from environment variables / a local, git-ignored file. Do not hard-code the test user's personal
  data; keep it in `profile.local.json` (git-ignored).
- Do not send profile data to any LLM or third party without explicit user consent. Keep profile data out of logs.
- Collect the minimum: broad region, not address; age range, not date of birth.

## 4. Requirements for the future live fetcher (does not exist yet)

It lives in its own module (`backend/fetchers/http.py`), is reviewed line by line, and MUST:

1. Only run for sources whose gate says allowed. Refuse everything else.
2. Fetch and obey `robots.txt` (cached), honour `Crawl-delay`, and never go below the source's `min_request_interval_seconds`.
3. Identify itself honestly (User-Agent with a contact URL). No spoofing to evade blocks, no proxy rotation.
4. **Stop on CAPTCHA, HTTP 403/429, or challenge pages**: mark the source `SUSPENDED` and alert a human. Never solve, bypass or retry around them.
5. Block SSRF: only http/https; resolve DNS and refuse non-public addresses at connect time (DNS-rebinding defence);
   re-validate every redirect target; cap redirects (<= 3).
6. Enforce timeouts, maximum response size, and content-type allow-list. Never send cookies or credentials. Never follow
   `javascript:`/`data:` links.
7. Never execute scripts (no headless browsers) unless a source's terms explicitly allow it and it is reviewed separately.

## 5. Requirements for LLM-assisted extraction (later)

- Page text is untrusted input. It goes to the model as quoted data with an instruction not to follow anything inside it.
- Output must parse into the schema; anything else is rejected. Each value needs a verbatim snippet that the pipeline
  re-checks (already implemented), and `method=LLM_EXTRACTION`.
- LLM output can raise a listing to at most `LIKELY_ELIGIBLE`. It can never produce `ELIGIBLE_VERIFIED`, and it never
  sets risk. Final eligibility and risk decisions are deterministic rules.
- The model receives no secrets and no user profile data.

## 6. Reviewing AI-written code (checklist)

Reject the change if any answer is "no" or "unsure":

- [ ] Diff touches only: one collector folder, its tests, and one line in each registry
- [ ] No new dependency; `requirements.txt` unchanged
- [ ] `python -m unittest discover -s tests -t .` is green and includes the contract tests
- [ ] No network call, file access, clock read, `eval/exec/open`, or DB access inside `backend/collectors/`
- [ ] Fixtures are hand-saved real pages with personal data removed, plus a must-reject case
- [ ] No listing sets eligibility, risk or scores
- [ ] Every value has a verbatim evidence snippet; unknown fields are `None`
- [ ] Reward certainty/basis are correct for each listing type
- [ ] No `verify=False`, no disabled certificate checks, no hard-coded secrets or URLs with credentials

## 7. Legal and privacy items needing professional review before launch

Australian competition/trade-promotion rules (some states require permits) and consumer law; the Spam Act 2003 (digest
emails need consent and an unsubscribe); the Privacy Act 1988; GDPR for French users; affiliate and sponsored-content
disclosure rules in both countries. Ranking must never depend on affiliate commission, and any sponsored placement must be
disclosed. Scoring (Step 6) must include a test proving commission fields cannot influence rank.

## 8. Known gaps (not implemented yet)

Live fetcher, robots.txt parser and rate limiter; authentication, CSRF and sessions (Phase 3); dashboard and output escaping
tests; database backup and encryption at rest; dependency pinning with hashes; CI running the tests on every change.
