# Opportunity Finder

Finds legitimate opportunities (paid research, product tests, competitions, cashback) and answers one question:
**"Which of these are actually worth my time?"** Accuracy and trust matter more than quantity.

This repository is at **Step 1: foundation**. It proves the architecture with one *fictional* source and saved HTML.
There are **no real collectors and no live network access yet**, on purpose.

- Product/engineering contract: [`SPEC.md`](SPEC.md)
- Security model and rules for future components: [`SECURITY.md`](SECURITY.md)

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt                        # just beautifulsoup4
python -m unittest discover -s tests -t .              # 142 tests, ~0.5 s, no network
python -m scripts.demo_mock_run                        # end-to-end demo on saved HTML
```

Requires Python 3.11+. The tests use `unittest` (standard library). They were run with `unittest` only;
they are written so `pytest` should also collect them, but that has not been verified.

## What exists

```
backend/
  domain/        Opportunity, Reward, Evidence, eligibility + risk models, enums, validators, policy rules
  database/      schema.sql (portable SQL), SQLite connection, Repository (all SQL lives here)
  sources/       SourceDefinition + registry: the written record of WHY we may collect from each source
  fetchers/      Fetcher protocol, RawDocument, FixtureFetcher (saved HTML). No live fetcher yet.
  normalizer/    money/duration parsing (AU + FR formats), HTML -> text
  collectors/    Collector base class, collector registry, the mock collector
  pipeline/      runner (gate -> fetch -> parse -> validate -> verify -> store -> report) + evidence verification
tests/           142 tests incl. collector contract tests and a static safety scanner
scripts/         demo_mock_run.py
```

## The pipeline in one picture

```
SourceRegistry ──gate──▶ Collector.urls() ──▶ Fetcher ──▶ RawDocument
 (permission record)       (fixture only today)                 │
                                                                ▼
   Repository ◀── validate + verify evidence ◀── Collector.parse()   (pure: text in, Opportunities out)
       │            (reject on any ERROR)
       ▼
   source_runs report  (every run recorded, including refusals)
```

Collectors **extract facts with evidence**. Separate engines (Steps 2, 4, 6) **decide** eligibility, risk and score.
A collector that tries to decide is rejected by the pipeline.

## How another AI (or person) adds a collector

Workflow: **AI drafts, you review, tests verify.** Do these in order, one source per change.

1. **Human, first: check permission.** Read the site's terms and `robots.txt`. Decide the `permission_basis`
   (official API, public feed, robots + terms allow, written permission, or manual only). If you are not sure, it is
   *not* permitted. Never bypass CAPTCHAs or anti-bot systems.
2. **Register the source** in `backend/sources/registry.py` as `DISABLED` or `FIXTURE_ONLY`. It cannot be `ENABLED`
   unless the terms review is recorded (the constructor refuses otherwise).
3. **Save sample pages by hand** (browser "Save as", 1-3 pages, remove personal data) into
   `backend/collectors/<category>/<source_id_with_underscores>/fixtures/`. The AI must not fetch pages itself.
   Include at least one listing that **must be rejected** (missing amount, unknown type, unsafe link...).
4. **Write `collector.py`** next to the fixtures. Copy `backend/collectors/testing/mock_competitions/collector.py`.
   Implement two methods only: `urls()` and `parse(doc, ctx)`.
5. **Register it** with one `CollectorSpec` in `backend/collectors/registry.py`. The contract tests then run on it
   automatically.
6. **Add `tests/test_<source>_collector.py`** asserting the specific values expected from your fixtures.
7. Run `python -m unittest discover -s tests -t .` until green. Report using the format at the bottom of this file.

### Rules for `parse()` (enforced by tests)

| Rule | Why | Enforced by |
|---|---|---|
| Pure function: no network, files, clock, randomness, DB, `eval/exec/open` | Reproducible, safe, testable | AST scan in `tests/test_collector_contract.py` |
| Use `ctx.now`, never `datetime.now()` | Deterministic runs | AST scan |
| Every claim gets `Evidence` with a **verbatim** snippet from the page | Trust; defeats made-up data | `validate_opportunity` + `verify_evidence_against_documents` |
| Unknown means `None`, never `False`/`0` | "No purchase stated" is not "no purchase needed" | Domain model + tests |
| Set reward **certainty and value basis** honestly (see SPEC 4) | A prize is never income | `Reward` rules + DB CHECKs |
| Do **not** set eligibility, risk or scores | Engines decide, collectors extract | Rule C1 in the pipeline |
| Reject rather than guess: `raise ParseError("reason")` via `result.attempt(...)` | A rejected listing is cheap; a wrong one destroys trust | Contract test requires a rejection fixture |
| Use the shared `parse_money` / `parse_duration_minutes` | One place for AU + FR formats | Reviewer |
| Bare `$` is ambiguous: resolve it from the page or reject | AUD vs USD matters | Shared parser returns `currency=None` |

### Prompt to give another AI

> You are adding one collector to the Opportunity Finder repo. Read `README.md`, `SPEC.md` and `SECURITY.md` first.
> Copy `backend/collectors/testing/mock_competitions/collector.py`. Implement only `urls()` and `parse()`.
> `parse()` must be a pure function of the saved HTML in `fixtures/`: no network, files, clock or randomness.
> Give every extracted claim an `Evidence` whose snippet is copied verbatim from the page. Leave unknown fields as
> `None`. Never set eligibility, risk or scores. Set reward `certainty`/`value_basis` per SPEC section 4: a competition
> prize is `CHANCE_BASED` + `PRIZE_VALUE`, never cash. If a listing is ambiguous, raise `ParseError` instead of guessing.
> Do not fetch any URL, do not add dependencies, do not touch files outside your collector folder, its tests, and one
> line each in the two registries. Finish with: what changed, tests run, bugs found, security concerns, next step.

### Reviewer checklist (you, the architect)

- [ ] `SourceDefinition` says *why* access is allowed, and `terms_reviewed_on` is a real human review
- [ ] Fixtures are real saved pages, contain a must-reject case, and contain no personal data
- [ ] Reward `certainty` and `value_basis` are honest for every listing type the site publishes
- [ ] No listing invents a value: every number traces to an `Evidence` snippet
- [ ] No new dependency; diff touches only the allowed files
- [ ] Rejection rate on the fixtures is sensible (not zero, not everything)

## Reporting format for every development step

What changed / tests run / bugs found / security concerns / next recommended step.
